#include "AbstractObserver.hpp"
#include "ConcreteSubject.hpp"


using namespace std;

AbstractObserver::AbstractObserver(){}
    
void AbstractObserver::Update(ConcreteSubject* subject) {}
